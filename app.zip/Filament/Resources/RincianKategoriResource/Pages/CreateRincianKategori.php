<?php

namespace App\Filament\Resources\RincianKategoriResource\Pages;

use App\Filament\Resources\RincianKategoriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRincianKategori extends CreateRecord
{
    protected static string $resource = RincianKategoriResource::class;
}
