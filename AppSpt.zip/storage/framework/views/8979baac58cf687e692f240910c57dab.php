<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan SPPD Dalam Daerah</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .subtitle {
            font-size: 14px;
            margin-bottom: 20px;
        }
        .filter-info {
            margin-bottom: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #000;
            padding: 5px;
        }
        th {
            background-color: #f0f0f0;
        }
        .footer {
            margin-top: 30px;
            text-align: right;
        }
    </style>
</head>
<body>
<div class="header">
    <div class="title">LAPORAN SPPD DALAM DAERAH</div>
    <div class="subtitle">Periode: <?php echo e($filters['tanggal_dari'] ?? 'Semua'); ?> s/d <?php echo e($filters['tanggal_sampai'] ?? 'Semua'); ?></div>
</div>

<?php if($filters['nomor_spt'] || $filters['user_id']): ?>
    <div class="filter-info">
        <strong>Filter yang digunakan:</strong><br>
        <?php if($filters['nomor_spt']): ?>
            Nomor SPT: <?php echo e($filters['nomor_spt']); ?><br>
        <?php endif; ?>
        <?php if($filters['user_id']): ?>
            User: <?php echo e(\App\Models\User::find($filters['user_id'])->name ?? 'Semua'); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>

<table>
    <thead>
    <tr>
        <th style="width: 5%">No</th>
        <th style="width: 15%">Nomor SPT</th>
        <th style="width: 20%">Nama User</th>
        <th style="width: 20%">Tujuan SPT</th>
        <th style="width: 20%">Tanggal SPT</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $sppdDalamDaerahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sppd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="text-align: center"><?php echo e($index + 1); ?></td>
            <td><?php echo e($sppd->nomor_spt); ?></td>
            <td><?php echo e($sppd->user->name ?? 'N/A'); ?></td>
            <td><?php echo e($sppd->tujuan_spt); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($sppd->tanggal_spt)->format('d-M-Y')); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="footer">
    <p>Dicetak oleh: <?php echo e($user->name); ?></p>
    <p>Dicetak pada: <?php echo e($tanggal_cetak); ?></p>
</div>
</body>
</html>
<?php /**PATH /home/avhan/Documents/APLIKASI/FILAMENT/AppSpt/resources/views/pdf/sppd_dalam_daerah.blade.php ENDPATH**/ ?>