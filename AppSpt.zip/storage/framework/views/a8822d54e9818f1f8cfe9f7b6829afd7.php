<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Perjalanan Dinas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .subtitle {
            font-size: 14px;
            margin-bottom: 20px;
        }
        .filter-info {
            margin-bottom: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #000;
            padding: 5px;
        }
        th {
            background-color: #f0f0f0;
        }
        .footer {
            margin-top: 30px;
            text-align: right;
        }
        .page-number {
            text-align: right;
            font-size: 10px;
            position: fixed;
            bottom: 10px;
            right: 10px;
        }
        .page-number:after {
            content: counter(page);
        }
    </style>
</head>
<body>
<div class="header">
    <div class="title">LAPORAN PERJALANAN DINAS</div>
    <div class="subtitle">Periode: <?php echo e($filters['tgl_berangkat_dari'] ?? 'Semua'); ?> s/d <?php echo e($filters['tgl_berangkat_sampai'] ?? 'Semua'); ?></div>
</div>

<?php if($filters['no_spt'] || $filters['user_id']): ?>
    <div class="filter-info">
        <strong>Filter yang digunakan:</strong><br>
        <?php if($filters['no_spt']): ?>
            Nomor SPT: <?php echo e($filters['no_spt']); ?><br>
        <?php endif; ?>
        <?php if($filters['user_id']): ?>
            User: <?php echo e($perjalanans->where('user_id', $filters['user_id'])->first()->user->name ?? ''); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>

<table>
    <thead>
    <tr>
        <th style="width: 5%">No</th>
        <th style="width: 15%">No SPT</th>
        <th style="width: 15%">Nama</th>
        <th style="width: 30%">Uraian</th>
        <th style="width: 15%">Tanggal Berangkat</th>
        <th style="width: 15%">Tanggal Kembali</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $perjalanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $perjalanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="text-align: center"><?php echo e($index + 1); ?></td>
            <td><?php echo e($perjalanan->no_spt); ?></td>
            <td><?php echo e($perjalanan->user->name); ?></td>
            <td><?php echo e($perjalanan->uraian); ?></td>
            <td style="text-align: center"><?php echo e(\Carbon\Carbon::parse($perjalanan->tgl_berangkat)->format('d-M-Y')); ?></td>
            <td style="text-align: center"><?php echo e(\Carbon\Carbon::parse($perjalanan->tgl_kembali)->format('d-M-Y')); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="footer">
    <p>Dicetak oleh: <?php echo e($user->name); ?><br>
        Tanggal: <?php echo e($tanggal_cetak); ?></p>
</div>

<div class="page-number">
    Halaman
</div>
</body>
</html>
<?php /**PATH /home/avhan/Documents/APLIKASI/FILAMENT/AppSpt/resources/views/pdf/perjalanan-dinas.blade.php ENDPATH**/ ?>