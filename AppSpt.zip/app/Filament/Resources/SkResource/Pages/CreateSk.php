<?php

namespace App\Filament\Resources\SkResource\Pages;

use App\Filament\Resources\SkResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSk extends CreateRecord
{
    protected static string $resource = SkResource::class;
}
