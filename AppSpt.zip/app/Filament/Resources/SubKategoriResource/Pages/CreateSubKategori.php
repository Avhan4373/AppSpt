<?php

namespace App\Filament\Resources\SubKategoriResource\Pages;

use App\Filament\Resources\SubKategoriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSubKategori extends CreateRecord
{
    protected static string $resource = SubKategoriResource::class;
}
